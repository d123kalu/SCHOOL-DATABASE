package main;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Time;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;

public class Main {
	
static DateFormat sdf = new SimpleDateFormat("hh:mm:ss");
	
	public static Time getTime(String time) throws ParseException {
		long date = sdf.parse(time).getTime();
		Time t = new Time(date);
		return t;
	}
	
	//For queries that return 2 columns
	public static void printResult(ResultSet rs) throws SQLException {
		System.out.println("Query Returned returned: ");
		while (rs.next())
		{
		    System.out.println(rs.getString(1)); 
		}
		rs.close();
		System.out.println("\n");
	}
	
	
	public static void main(String[] argv)
	  {

	      Connection conn;
	      ResultSet rs = null;
	      try
	      {
	        Class.forName("org.postgresql.Driver");
	        String dbURL = "jdbc:postgresql://localhost:5432/LAB 5/ PROJECT";
	        String user = "postgres";
	        String pass = "Arsenal17";

	        conn = DriverManager.getConnection(dbURL, user, pass);
	        Statement stmt = conn.createStatement();
	        PreparedStatement p = null;
	        String sql;
	       
	        //1
			 sql = "INSERT INTO \"Movie\" " +
	                   "VALUES (22, 'Django Unchained', 'December 25, 2012', 100000000)";
			stmt.executeUpdate(sql);
			
			p = conn.prepareStatement("INSERT INTO \"Movie\" VALUES "
					+ "(?, ?, ?, ?)");
			p.setInt(1, 23);
			p.setString(2, "Deadpool");
			p.setString(3, "February 12, 2016");
			p.setInt(4, 58000000);
			p.executeUpdate();
			
			//2
			sql = "INSERT INTO \"Writer\""
					+ "VALUES (11, 'Quentin Tarantino')";
			stmt.executeUpdate(sql);
			
			p = conn.prepareStatement("INSERT INTO \"Writer\" VALUES "
					+ "(?, ?)");
			p.setInt(1, 12);
			p.setString(2, "Rhett Reese");
			p.executeUpdate();
			
			
			//3
			sql = "INSERT INTO \"Genre\""
					+ "VALUES (11, 'Fiction', 'All made up')";
			stmt.executeUpdate(sql);
			
			p = conn.prepareStatement("INSERT INTO \"Genre\" VALUES "
					+ "(?, ?, ?)");
			p.setInt(1, 12);
			p.setString(2, "Anime");
			p.setString(3, " Japanese term for hand-drawn or computer animation. ");
			p.executeUpdate();
			
			
			//4
			sql = "INSERT INTO \"Producer\""
					+ "VALUES (11, 'Stacey Sher')";
			stmt.executeUpdate(sql);
			
			p = conn.prepareStatement("INSERT INTO \"Producer\" VALUES "
					+ "(?, ?)");
			p.setInt(1, 12);
			p.setString(2, "Simon Kinberg");
			p.executeUpdate();
			
			
			//5
			 sql = "INSERT INTO \"Location\""
					+ "VALUES (11, 1 ,'Canada', 'Ontario', 'Oshawa')";
			stmt.executeUpdate(sql);
		
			p = conn.prepareStatement("INSERT INTO \"Location\" VALUES "
					+ "(?, ?, ?, ?,?)");
			p.setInt(1, 12);
			p.setInt(2, 2);
			p.setString(3, "Canada");
			p.setString(4, "Ontario");
			p.setString(5, "Guelph");
			p.executeUpdate();
			
			
			//6
			sql = "INSERT INTO \"Actor\""
					+ "VALUES (11, 5, 'Jamie Foxx', 'Black')";
			stmt.executeUpdate(sql);
			
			p = conn.prepareStatement("INSERT INTO \"Actor\" VALUES "
					+ "(?, ?, ?, ?)");
			p.setInt(1, 12);
			p.setInt(2, 12);
			p.setString(3, "T. J. Miller");
			p.setString(4, "Brown");
			p.executeUpdate();
			
			
			//7
		    sql = "INSERT INTO \"Director\""
					+ "VALUES (11, 6, 'Quentin Tarantino')";
			stmt.executeUpdate(sql);
			
			p = conn.prepareStatement("INSERT INTO \"Director\" VALUES "
					+ "(?, ?, ?)");
			p.setInt(1, 12);
			p.setInt(2, 12);
			p.setString(3, "Tim Miller");
			p.executeUpdate();
			
			
			//8
			sql = "INSERT INTO \"Review\""
					+ "VALUES (22, 86, 90)";
			stmt.executeUpdate(sql);
			
			p = conn.prepareStatement("INSERT INTO \"Review\" VALUES "
					+ "(?, ?, ?)");
			p.setInt(1, 23);
			p.setInt(2, 88);
			p.setInt(3, 90);
			p.executeUpdate();
			
			
			//9
			sql = "INSERT INTO 	\"Famous Quote\""
					+ "VALUES ('I like the way you die boy.', 22)";
			stmt.executeUpdate(sql);
			
			p = conn.prepareStatement("INSERT INTO \"Famous Quote\" VALUES "
					+ "(?, ?)");
			p.setString(2, "Daddy Needs To Express Some Rage.");
			p.setInt(1, 23);
			p.executeUpdate();
			
			//10
			
			sql = "INSERT INTO 	\"Awards\""
					+ "VALUES (11, 21, 'Golden Globe Award for Best Screenplay - Motion Picture 2013')";
			stmt.executeUpdate(sql);
			
			p = conn.prepareStatement("INSERT INTO \"Awards\" VALUES "
					+ "(?, ?, ?)");
			p.setInt(1, 12);
			p.setInt(2, 23);
			p.setString(3, "MTV Movie Award for Best Fight 2016");
			p.executeUpdate();
			
			
			//11
			sql = "INSERT INTO 	\"Cinema\""
					+ "VALUES (11, 'Cinema Town')";
			stmt.executeUpdate(sql);
			p = conn.prepareStatement("INSERT INTO \"Cinema\" VALUES "
					+ "(?, ?)");
			p.setInt(1, 12);
			p.setString(2, "Theatre of dreams");
			p.executeUpdate();
			
			
			//12
			sql = "INSERT INTO 	\"Show time\""
					+ "VALUES (22, 11, 12)";
			stmt.executeUpdate(sql);
			p = conn.prepareStatement("INSERT INTO \"Show time\" VALUES "
					+ "(?, ?, ?)");
			p.setInt(1, 12);
			p.setInt(2, 12);
			p.setInt(3, 15);
			p.executeUpdate();
			
			
			//13
			sql = "INSERT INTO 	\"Movie Category\""
					+ "VALUES (22, 6)";
			stmt.executeUpdate(sql);
			
			p = conn.prepareStatement("INSERT INTO \"Movie Category\" VALUES "
					+ "(?, ?)");
			p.setInt(1, 23);
			p.setInt(2, 6);
			p.executeUpdate();
			
			//14
			 sql = "INSERT INTO 	\"Writer Movie Relationship\""
					+ "VALUES (22, 11)";
			stmt.executeUpdate(sql);
			p = conn.prepareStatement("INSERT INTO \"Writer Movie Relationship\" VALUES "
					+ "(?, ?)");
			p.setInt(1, 23);
			p.setInt(2, 12);
			p.executeUpdate();
			
			
			//15
			sql = "INSERT INTO 	\"Movie Producer Relationship\""
					+ "VALUES (22, 11)";
			stmt.executeUpdate(sql);
			p = conn.prepareStatement("INSERT INTO \"Movie Producer Relationship\" VALUES "
					+ "(?, ?)");
			p.setInt(1, 23);
			p.setInt(2, 12);
			p.executeUpdate();
			
			
			//16
			sql = "INSERT INTO 	\"Director Movie Relationship\""
					+ "VALUES (11, 22)";
			stmt.executeUpdate(sql);
			p = conn.prepareStatement("INSERT INTO \"Director Movie Relationship\" VALUES "
					+ "(?, ?)");
			p.setInt(1, 12);
			p.setInt(2, 23);
			p.executeUpdate();
			
			
			//17
			sql = "INSERT INTO 	\"Actor movie Relationship\""
					+ "VALUES (11, 22)";
			stmt.executeUpdate(sql);
			p = conn.prepareStatement("INSERT INTO \"Actor movie Relationship\" VALUES "
					+ "(?, ?)");
			p.setInt(1, 12);
			p.setInt(2, 23);
			p.executeUpdate();
			
			
	        //SELECT statements
	        //********* 1 ************
	        //sql = "SELECT \"Director\".\"Name\"" + 
	        //		"		FROM \"Director\", \"Location\"" + 
	        //		"		WHERE \"Location\".\"Country\" = 'Canada' AND \"Location\".\"LocationID\" = \"Director\".\"LocationID\" ";
			//rs = stmt.executeQuery(sql);
			//printResult(rs);
			
	        p = conn.prepareStatement("SELECT \"Movie\".\"Name\"" +
	        		"FROM \"Movie\",\"Director\",\"Director Movie Relationship\"" +
	        		"WHERE \"Movie\".\"MovieID\" = \"Director Movie Relationship\".\"MovieID\" " +
	        			"AND \"Director\".\"DirectorID\" = \"Director Movie Relationship\".\"DirectorID\" "+
	        			"AND \"Director\".\"Name\" = ?");
			p.setString(1, "Louis Leterrier");
			rs = p.executeQuery();
			printResult(rs);
	        
	        
	        //********* 2 **********
	        sql = "SELECT \"Actor\".\"Name\", \"Movie\".\"Budget\" as \"USD\", " +
	    			"(\"Movie\".\"Budget\")* 1.27 as \"CAD\", (\"Movie\".\"Budget\")* 113.75 as \"JPY\"," +
	    			"(\"Movie\".\"Budget\")* 59.25 as \"RUB\", (\"Movie\".\"Budget\")* 0.86 as \"EUR\"," +
	            		"(\"Movie\".\"Budget\")* 1.00 as \"CHF\"" +
	    		"FROM \"Movie\",\"Actor\",\"Actor movie Relationship\" "+
	    		"WHERE  \"Movie\".\"MovieID\" = \"Actor movie Relationship\".\"MovieID\" " +
	    			"AND \"Actor\".\"ActorID\" = \"Actor movie Relationship\".\"ActorID\"" +
	    			"AND \"Movie\".\"Budget\" >= 1000000";
	    			rs = stmt.executeQuery(sql);
	    	printResult(rs);
	        
	        p = conn.prepareStatement(" SELECT \"Movie\".\"Name\"\r\n" + 
	        		"		FROM \"Movie\", \"Genre\", \"Movie Category\"\r\n" + 
	        		"		WHERE \"Movie\".\"MovieID\" = \"Movie Category\".\"MovieID\"\r\n" + 
	        		"			AND \"Movie Category\".\"GenreID\" = \"Genre\".\"GenreID\" \r\n" + 
	        		"        		AND \"Genre\".\"Name\" = ?;");
			p.setString(1, "Comedy");
			rs = p.executeQuery();
			printResult(rs);
	        
	        
	        
	        //******** 3 **********
	        sql = "SELECT \"Name\"\r\n" + 
	        		"		FROM \"Director\"\r\n" + 
	        		"		WHERE \"Name\" LIKE 'J%' OR \"Name\" LIKE 'S%'";
	    			rs = stmt.executeQuery(sql);
	    	printResult(rs);
	        
	        p = conn.prepareStatement("SELECT COUNT(\"Location\".\"Country\")\n" + 
	        		"		FROM \"Location\", \"Actor\", \"Actor movie Relationship\", \"Movie\"\r\n" + 
	        		"		WHERE \"Movie\".\"Name\" = ? AND \"Movie\".\"MovieID\" = \"Actor movie Relationship\".\"MovieID\"\r\n" + 
	        		"		AND \"Actor movie Relationship\".\"ActorID\" = \"Actor\".\"ActorID\"\r\n" + 
	        		"        	AND \"Location\".\"LocationID\" = \"Actor\".\"LocationID\"");
			p.setString(1, "Iron Man");
			rs = p.executeQuery();
			printResult(rs);
	       
	        
	        
	        //********  4 *******
	        sql = "SELECT AVG(\"Show time\".\"Price\") as \"Average price of ticket\"\r\n" + 
	        		"		FROM \"Show time\"";
	    			rs = stmt.executeQuery(sql);
	    	printResult(rs);
	        
	        p = conn.prepareStatement("SELECT COUNT(\"Eye Color\")as \"Number of people with brown eyes\"\r\n" + 
	        		"		FROM \"Actor\"\r\n" + 
	        		"		WHERE \"Actor\".\"Eye Color\" = ?");
			p.setString(1, "Brown");
			rs = p.executeQuery();
			printResult(rs);
	      } catch (Exception ex)
	      {
	          ex.printStackTrace();
		    }
	    }

}
